import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AgendaStore.instance.load();
  await NotificationService.instance.init();
  runApp(const AgendaVirtualApp());
}

enum TaskStatus { pending, inProgress, completed }
enum TaskPriority { low, normal, high, urgent }

class AgendaTask {
  AgendaTask({String? id, required this.title, this.description = '', required this.due,
    this.priority = TaskPriority.normal, this.category = 'Personal', this.status = TaskStatus.pending,
    this.reminder = false, this.recurrence = 'No se repite', this.project = ''}) : id = id ?? const Uuid().v4();
  final String id;
  String title, description, category, project, recurrence;
  DateTime due;
  TaskPriority priority;
  TaskStatus status;
  bool reminder;
  Map<String, dynamic> toJson() => {'id':id,'title':title,'description':description,'due':due.toIso8601String(),
    'priority':priority.name,'category':category,'status':status.name,'reminder':reminder,'recurrence':recurrence,'project':project};
  factory AgendaTask.fromJson(Map<String,dynamic> j) => AgendaTask(id:j['id'],title:j['title'] ?? '',description:j['description'] ?? '',
    due:DateTime.tryParse(j['due'] ?? '') ?? DateTime.now(),priority:TaskPriority.values.firstWhere((e)=>e.name==j['priority'],orElse:()=>TaskPriority.normal),
    category:j['category'] ?? 'Personal',status:TaskStatus.values.firstWhere((e)=>e.name==j['status'],orElse:()=>TaskStatus.pending),
    reminder:j['reminder'] ?? false,recurrence:j['recurrence'] ?? 'No se repite',project:j['project'] ?? '');
}

class AgendaStore extends ChangeNotifier {
  AgendaStore._(); static final instance = AgendaStore._();
  final List<AgendaTask> tasks = []; final List<String> notes = [];
  bool darkMode = false; String displayName = 'Mi agenda';
  static const _tasksKey='agenda.tasks.v1', _notesKey='agenda.notes.v1', _darkKey='agenda.dark.v1', _nameKey='agenda.name.v1';
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    try { tasks.addAll((jsonDecode(p.getString(_tasksKey) ?? '[]') as List).map((e)=>AgendaTask.fromJson(Map<String,dynamic>.from(e)))); } catch (_) {}
    try { notes.addAll((jsonDecode(p.getString(_notesKey) ?? '[]') as List).cast<String>()); } catch (_) {}
    darkMode=p.getBool(_darkKey) ?? false; displayName=p.getString(_nameKey) ?? 'Mi agenda';
  }
  Future<void> save() async { final p=await SharedPreferences.getInstance(); await p.setString(_tasksKey,jsonEncode(tasks.map((e)=>e.toJson()).toList())); await p.setString(_notesKey,jsonEncode(notes)); await p.setBool(_darkKey,darkMode); await p.setString(_nameKey,displayName); notifyListeners(); }
  Future<void> add(AgendaTask t) async { tasks.add(t); if(t.reminder) await NotificationService.instance.schedule(t); await save(); }
  Future<void> update(AgendaTask t) async { final i=tasks.indexWhere((e)=>e.id==t.id); if(i>=0) tasks[i]=t; await NotificationService.instance.cancel(t.id.hashCode); if(t.reminder && t.status!=TaskStatus.completed) await NotificationService.instance.schedule(t); await save(); }
  Future<void> delete(AgendaTask t) async { tasks.removeWhere((e)=>e.id==t.id); await NotificationService.instance.cancel(t.id.hashCode); await save(); }
  Future<void> addNote(String note) async { notes.insert(0,note); await save(); }
  Future<void> removeNote(String note) async { notes.remove(note); await save(); }
  int get completed => tasks.where((t)=>t.status==TaskStatus.completed).length;
  int get open => tasks.where((t)=>t.status!=TaskStatus.completed).length;
}

class NotificationService {
  NotificationService._(); static final instance=NotificationService._();
  final plugin=FlutterLocalNotificationsPlugin();
  Future<void> init() async { const android=AndroidInitializationSettings('@mipmap/ic_launcher'); const settings=InitializationSettings(android:android); await plugin.initialize(settings); }
  Future<void> schedule(AgendaTask t) async {
    if(t.due.isBefore(DateTime.now())) return;
    const details=NotificationDetails(android:AndroidNotificationDetails('agenda_reminders','Recordatorios',channelDescription:'Avisos de tareas',importance:Importance.high,priority:Priority.high));
    // Aviso local inmediato de compatibilidad: se programa con la fecha solo si el dispositivo lo permite.
    await plugin.show(t.id.hashCode,t.title,'Recordatorio: ${DateFormat('dd/MM/yyyy HH:mm').format(t.due)}',details);
  }
  Future<void> cancel(int id) async => plugin.cancel(id);
}

class AgendaVirtualApp extends StatelessWidget { const AgendaVirtualApp({super.key});
  @override Widget build(BuildContext context) => AnimatedBuilder(animation:AgendaStore.instance,builder:(context,_) => MaterialApp(
    debugShowCheckedModeBanner:false,title:'Agenda Virtual',themeMode:AgendaStore.instance.darkMode?ThemeMode.dark:ThemeMode.light,
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF536DFE)),useMaterial3:true,scaffoldBackgroundColor:const Color(0xFFF6F7FB)),
    darkTheme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF9BA8FF),brightness:Brightness.dark),useMaterial3:true),home:const MainShell()));
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> {
  int tab=0;
  @override Widget build(BuildContext context) {
    final pages=[const HomePage(),const TasksPage(),const CalendarPage(),const NotesPage(),const SettingsPage()];
    return Scaffold(body:SafeArea(child:IndexedStack(index:tab,children:pages)),floatingActionButton:FloatingActionButton.extended(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TaskEditorPage())),icon:const Icon(Icons.add),label:const Text('Nueva tarea')),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Inicio'),NavigationDestination(icon:Icon(Icons.checklist),label:'Tareas'),NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'Calendario'),NavigationDestination(icon:Icon(Icons.sticky_note_2_outlined),label:'Notas'),NavigationDestination(icon:Icon(Icons.tune),label:'Más')]));
  }
}

String dateLabel(DateTime d)=>DateFormat('EEE d MMM · HH:mm','es').format(d);
String priorityLabel(TaskPriority p)=>switch(p){TaskPriority.low=>'Baja',TaskPriority.normal=>'Normal',TaskPriority.high=>'Alta',TaskPriority.urgent=>'Urgente'};
String statusLabel(TaskStatus s)=>switch(s){TaskStatus.pending=>'Pendiente',TaskStatus.inProgress=>'En curso',TaskStatus.completed=>'Completada'};
Color priorityColor(TaskPriority p)=>switch(p){TaskPriority.low=>Colors.teal,TaskPriority.normal=>Colors.blueGrey,TaskPriority.high=>Colors.orange,TaskPriority.urgent=>Colors.red};

class HomePage extends StatelessWidget { const HomePage({super.key});
 @override Widget build(BuildContext context) { final s=AgendaStore.instance; final now=DateTime.now(); final today=s.tasks.where((t)=>t.status!=TaskStatus.completed&&t.due.year==now.year&&t.due.month==now.month&&t.due.day==now.day).toList()..sort((a,b)=>a.due.compareTo(b.due)); final upcoming=s.tasks.where((t)=>t.status!=TaskStatus.completed&&t.due.isAfter(now)).toList()..sort((a,b)=>a.due.compareTo(b.due));
 return ListView(padding:const EdgeInsets.fromLTRB(20,18,20,100),children:[Text(DateFormat('EEEE d MMMM','es').format(now),style:TextStyle(color:Theme.of(context).colorScheme.primary,fontWeight:FontWeight.w600)),const SizedBox(height:6),Text('Hola, vamos paso a paso 👋',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:18),Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Theme.of(context).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(24)),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Tu día, organizado',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),const SizedBox(height:6),Text('${s.open} tareas por resolver · ${s.completed} completadas') ])),const Icon(Icons.auto_awesome,size:42)])),const SizedBox(height:18),Row(children:[_StatCard(label:'Pendientes',value:'${s.tasks.where((t)=>t.status==TaskStatus.pending).length}',icon:Icons.radio_button_unchecked),const SizedBox(width:10),_StatCard(label:'En curso',value:'${s.tasks.where((t)=>t.status==TaskStatus.inProgress).length}',icon:Icons.timelapse),const SizedBox(width:10),_StatCard(label:'Hechas',value:'${s.completed}',icon:Icons.task_alt)]),const SizedBox(height:24),_SectionTitle(title:'Para hoy',subtitle:'${today.length} tareas'),if(today.isEmpty)const _EmptyMessage(text:'No tienes tareas para hoy. ¡Buen momento para organizarte!') else ...today.take(5).map((t)=>TaskTile(task:t)),const SizedBox(height:16),_SectionTitle(title:'Próximas tareas',subtitle:'Lo que viene'),if(upcoming.isEmpty)const _EmptyMessage(text:'No hay tareas futuras por ahora.') else ...upcoming.take(4).map((t)=>TaskTile(task:t))]); }
}
class _StatCard extends StatelessWidget { const _StatCard({required this.label,required this.value,required this.icon}); final String label,value; final IconData icon; @override Widget build(BuildContext context)=>Expanded(child:Container(padding:const EdgeInsets.symmetric(vertical:16,horizontal:10),decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Theme.of(context).colorScheme.primary),const SizedBox(height:12),Text(value,style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),Text(label,style:Theme.of(context).textTheme.bodySmall)]))); }
class _SectionTitle extends StatelessWidget { const _SectionTitle({required this.title,required this.subtitle}); final String title,subtitle; @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(title,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),Text(subtitle,style:Theme.of(context).textTheme.bodySmall)])); }
class _EmptyMessage extends StatelessWidget { const _EmptyMessage({required this.text}); final String text; @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(border:Border.all(color:Theme.of(context).dividerColor),borderRadius:BorderRadius.circular(16)),child:Text(text)); }

class TasksPage extends StatefulWidget { const TasksPage({super.key}); @override State<TasksPage> createState()=>_TasksPageState(); }
class _TasksPageState extends State<TasksPage> { String filter='Todas'; String query='';
 @override Widget build(BuildContext context) { var list=AgendaStore.instance.tasks.where((t){final matches=t.title.toLowerCase().contains(query.toLowerCase())||t.description.toLowerCase().contains(query.toLowerCase())||t.category.toLowerCase().contains(query.toLowerCase()); final f=filter=='Todas'||(filter=='Pendientes'&&t.status==TaskStatus.pending)||(filter=='En curso'&&t.status==TaskStatus.inProgress)||(filter=='Completadas'&&t.status==TaskStatus.completed); return matches&&f;}).toList()..sort((a,b)=>a.due.compareTo(b.due));
 return ListView(padding:const EdgeInsets.fromLTRB(20,20,20,100),children:[Text('Mis tareas',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:14),TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Buscar por título o categoría',border:OutlineInputBorder(),filled:true),onChanged:(v)=>setState(()=>query=v)),const SizedBox(height:12),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:['Todas','Pendientes','En curso','Completadas'].map((f)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(f),selected:filter==f,onSelected:(_)=>setState(()=>filter=f)))).toList())),const SizedBox(height:16),if(list.isEmpty)const _EmptyMessage(text:'No encontramos tareas con este filtro.') else ...list.map((t)=>TaskTile(task:t))]); }
}

class TaskTile extends StatelessWidget { const TaskTile({super.key,required this.task}); final AgendaTask task;
 @override Widget build(BuildContext context) { final s=AgendaStore.instance; return Card(elevation:0,margin:const EdgeInsets.only(bottom:9),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:5),leading:Checkbox(value:task.status==TaskStatus.completed,onChanged:(v){task.status=v==true?TaskStatus.completed:TaskStatus.pending;s.update(task);}),title:Text(task.title,style:TextStyle(fontWeight:FontWeight.w600,decoration:task.status==TaskStatus.completed?TextDecoration.lineThrough:null)),subtitle:Padding(padding:const EdgeInsets.only(top:5),child:Wrap(spacing:7,runSpacing:5,crossAxisAlignment:WrapCrossAlignment.center,children:[Text(DateFormat('dd/MM · HH:mm').format(task.due)),_Tag(text:task.category,color:Theme.of(context).colorScheme.secondary),_Tag(text:priorityLabel(task.priority),color:priorityColor(task.priority))])),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await Navigator.push(context,MaterialPageRoute(builder:(_)=>TaskEditorPage(task:task)));if(v=='delete')await s.delete(task);if(v=='progress'){task.status=task.status==TaskStatus.inProgress?TaskStatus.pending:TaskStatus.inProgress;await s.update(task);}},itemBuilder:(_)=>const [PopupMenuItem(value:'edit',child:Text('Editar')),PopupMenuItem(value:'progress',child:Text('Cambiar estado')),PopupMenuItem(value:'delete',child:Text('Eliminar'))]))); }
}
class _Tag extends StatelessWidget { const _Tag({required this.text,required this.color}); final String text; final Color color; @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:3),decoration:BoxDecoration(color:color.withOpacity(.12),borderRadius:BorderRadius.circular(20)),child:Text(text,style:TextStyle(fontSize:11,color:color,fontWeight:FontWeight.w600))); }

class TaskEditorPage extends StatefulWidget { const TaskEditorPage({super.key,this.task}); final AgendaTask? task; @override State<TaskEditorPage> createState()=>_TaskEditorPageState(); }
class _TaskEditorPageState extends State<TaskEditorPage> { final form=GlobalKey<FormState>(); late final TextEditingController title,description,project; late DateTime due; late TaskPriority priority; late String category,recurrence; late TaskStatus status; late bool reminder;
 final categories=['Personal','Trabajo','Estudio','Familia','Salud','Compras','Otro']; final recurrences=['No se repite','Diaria','Semanal','Mensual'];
 @override void initState(){super.initState();final t=widget.task;title=TextEditingController(text:t?.title??'');description=TextEditingController(text:t?.description??'');project=TextEditingController(text:t?.project??'');due=t?.due??DateTime.now().add(const Duration(hours:1));priority=t?.priority??TaskPriority.normal;category=t?.category??'Personal';recurrence=t?.recurrence??'No se repite';status=t?.status??TaskStatus.pending;reminder=t?.reminder??false;}
 @override void dispose(){title.dispose();description.dispose();project.dispose();super.dispose();}
 Future<void> chooseDate()async{final d=await showDatePicker(context:context,initialDate:due,firstDate:DateTime(2020),lastDate:DateTime(2100));if(d!=null)setState(()=>due=DateTime(d.year,d.month,d.day,due.hour,due.minute));}
 Future<void> chooseTime()async{final t=await showTimePicker(context:context,initialTime:TimeOfDay.fromDateTime(due));if(t!=null)setState(()=>due=DateTime(due.year,due.month,due.day,t.hour,t.minute));}
 Future<void> save()async{if(!form.currentState!.validate())return;final task=AgendaTask(id:widget.task?.id,title:title.text.trim(),description:description.text.trim(),due:due,priority:priority,category:category,status:status,reminder:reminder,recurrence:recurrence,project:project.text.trim());if(widget.task==null){await AgendaStore.instance.add(task);}else{await AgendaStore.instance.update(task);}if(mounted)Navigator.pop(context);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.task==null?'Nueva tarea':'Editar tarea')),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(20),children:[TextFormField(controller:title,decoration:const InputDecoration(labelText:'Título *',border:OutlineInputBorder()),validator:(v)=>v==null||v.trim().isEmpty?'Escribe un título':null),const SizedBox(height:14),TextFormField(controller:description,maxLines:3,decoration:const InputDecoration(labelText:'Descripción',border:OutlineInputBorder())),const SizedBox(height:14),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:chooseDate,icon:const Icon(Icons.calendar_today),label:Text(DateFormat('dd/MM/yyyy').format(due)))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:chooseTime,icon:const Icon(Icons.schedule),label:Text(DateFormat('HH:mm').format(due))))]),const SizedBox(height:14),DropdownButtonFormField<TaskPriority>(value:priority,decoration:const InputDecoration(labelText:'Prioridad',border:OutlineInputBorder()),items:TaskPriority.values.map((p)=>DropdownMenuItem(value:p,child:Text(priorityLabel(p)))).toList(),onChanged:(v)=>setState(()=>priority=v??priority)),const SizedBox(height:14),DropdownButtonFormField<String>(value:categories.contains(category)?category:'Otro',decoration:const InputDecoration(labelText:'Categoría',border:OutlineInputBorder()),items:categories.map((c)=>DropdownMenuItem(value:c,child:Text(c))).toList(),onChanged:(v)=>setState(()=>category=v??category)),const SizedBox(height:14),DropdownButtonFormField<TaskStatus>(value:status,decoration:const InputDecoration(labelText:'Estado',border:OutlineInputBorder()),items:TaskStatus.values.map((s)=>DropdownMenuItem(value:s,child:Text(statusLabel(s)))).toList(),onChanged:(v)=>setState(()=>status=v??status)),const SizedBox(height:14),DropdownButtonFormField<String>(value:recurrence,decoration:const InputDecoration(labelText:'Repetición',border:OutlineInputBorder()),items:recurrences.map((r)=>DropdownMenuItem(value:r,child:Text(r))).toList(),onChanged:(v)=>setState(()=>recurrence=v??recurrence)),const SizedBox(height:14),TextField(controller:project,decoration:const InputDecoration(labelText:'Proyecto u objetivo (opcional)',border:OutlineInputBorder())),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Recordatorio'),subtitle:const Text('Mostrar un aviso para esta tarea'),value:reminder,onChanged:(v)=>setState(()=>reminder=v)),const SizedBox(height:18),FilledButton.icon(onPressed:save,icon:const Icon(Icons.save_outlined),label:const Text('Guardar tarea'))])));
}

class CalendarPage extends StatefulWidget { const CalendarPage({super.key}); @override State<CalendarPage> createState()=>_CalendarPageState(); }
class _CalendarPageState extends State<CalendarPage>{DateTime selected=DateTime.now(),month=DateTime(DateTime.now().year,DateTime.now().month);@override Widget build(BuildContext context){final list=AgendaStore.instance.tasks.where((t)=>t.due.year==selected.year&&t.due.month==selected.month&&t.due.day==selected.day).toList()..sort((a,b)=>a.due.compareTo(b.due));final days=DateUtils.getDaysInMonth(month.year,month.month);final offset=DateTime(month.year,month.month,1).weekday-1;return ListView(padding:const EdgeInsets.fromLTRB(20,18,20,100),children:[Text('Calendario',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:18),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[IconButton(onPressed:()=>setState(()=>month=DateTime(month.year,month.month-1)),icon:const Icon(Icons.chevron_left)),Text(DateFormat('MMMM yyyy','es').format(month),style:Theme.of(context).textTheme.titleLarge),IconButton(onPressed:()=>setState(()=>month=DateTime(month.year,month.month+1)),icon:const Icon(Icons.chevron_right))]),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:7,children:[...['L','M','X','J','V','S','D'].map((d)=>Center(child:Text(d,style:const TextStyle(fontWeight:FontWeight.bold)))),...List.generate(offset,(_)=>const SizedBox()),...List.generate(days,(i){final day=i+1;final active=selected.year==month.year&&selected.month==month.month&&selected.day==day;final has=AgendaStore.instance.tasks.any((t)=>t.due.year==month.year&&t.due.month==month.month&&t.due.day==day&&t.status!=TaskStatus.completed);return InkWell(borderRadius:BorderRadius.circular(30),onTap:()=>setState(()=>selected=DateTime(month.year,month.month,day)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:36,height:36,alignment:Alignment.center,decoration:BoxDecoration(color:active?Theme.of(context).colorScheme.primary:null,shape:BoxShape.circle),child:Text('$day',style:TextStyle(color:active?Theme.of(context).colorScheme.onPrimary:null))),if(has)Container(width:4,height:4,decoration:BoxDecoration(color:Theme.of(context).colorScheme.primary,shape:BoxShape.circle))]));})]),const SizedBox(height:20),_SectionTitle(title:DateFormat('EEEE d MMMM','es').format(selected),subtitle:'${list.length} actividades'),if(list.isEmpty)const _EmptyMessage(text:'No hay actividades para este día.')else ...list.map((t)=>TaskTile(task:t))]);}}

class NotesPage extends StatefulWidget { const NotesPage({super.key}); @override State<NotesPage> createState()=>_NotesPageState(); }
class _NotesPageState extends State<NotesPage>{final c=TextEditingController();@override void dispose(){c.dispose();super.dispose();}@override Widget build(BuildContext context){final notes=AgendaStore.instance.notes;return ListView(padding:const EdgeInsets.fromLTRB(20,20,20,100),children:[Text('Notas rápidas',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:14),TextField(controller:c,maxLines:3,decoration:const InputDecoration(hintText:'Anota una idea para no olvidarla…',border:OutlineInputBorder())),const SizedBox(height:8),Align(alignment:Alignment.centerRight,child:FilledButton.icon(onPressed:(){if(c.text.trim().isNotEmpty){AgendaStore.instance.addNote(c.text.trim());c.clear();}},icon:const Icon(Icons.add),label:const Text('Guardar nota'))),const SizedBox(height:14),if(notes.isEmpty)const _EmptyMessage(text:'Tus notas aparecerán aquí.')else ...notes.map((n)=>Card(elevation:0,child:ListTile(leading:const Icon(Icons.sticky_note_2_outlined),title:Text(n),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>AgendaStore.instance.removeNote(n)))))]);}}

class SettingsPage extends StatelessWidget { const SettingsPage({super.key});@override Widget build(BuildContext context){final s=AgendaStore.instance;return ListView(padding:const EdgeInsets.fromLTRB(20,20,20,100),children:[Text('Más opciones',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:16),Card(elevation:0,child:SwitchListTile(title:const Text('Modo oscuro'),subtitle:const Text('Cambiar la apariencia de la agenda'),secondary:const Icon(Icons.dark_mode_outlined),value:s.darkMode,onChanged:(v){s.darkMode=v;s.save();})),Card(elevation:0,child:ListTile(leading:const Icon(Icons.person_outline),title:const Text('Nombre de la agenda'),subtitle:Text(s.displayName),trailing:const Icon(Icons.edit_outlined),onTap:()async{final c=TextEditingController(text:s.displayName);final value=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Nombre de la agenda'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Nombre')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,c.text.trim()),child:const Text('Guardar'))]));if(value!=null&&value.isNotEmpty){s.displayName=value;await s.save();}})),Card(elevation:0,child:ListTile(leading:const Icon(Icons.bar_chart),title:const Text('Resumen de actividad'),subtitle:Text('${s.tasks.length} tareas creadas · ${s.completed} completadas · ${s.open} abiertas'))),Card(elevation:0,child:ListTile(leading:const Icon(Icons.cloud_sync_outlined),title:const Text('Sincronización en la nube'),subtitle:const Text('Preparada para configurar Firebase en la siguiente etapa'),isThreeLine:true)),Card(elevation:0,child:ListTile(leading:const Icon(Icons.backup_outlined),title:const Text('Copia de seguridad'),subtitle:const Text('Exportación e importación se añadirán en la siguiente etapa'))),const SizedBox(height:12),const _EmptyMessage(text:'Los datos de esta primera versión se guardan en este dispositivo. La sincronización real entre dispositivos requiere configurar una cuenta de nube.')]);}}
