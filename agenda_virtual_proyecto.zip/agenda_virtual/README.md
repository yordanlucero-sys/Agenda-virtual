# Agenda Virtual — proyecto Flutter

Primera base funcional editable para Android. Incluye tareas, edición/eliminación, estados, prioridades, categorías, búsqueda, calendario mensual, notas rápidas, estadísticas sencillas, modo oscuro y almacenamiento local.

## Requisitos
- Flutter SDK estable instalado
- Android Studio con Android SDK

## Ejecutar
```bash
flutter pub get
flutter run
```

## Generar APK en un computador con Flutter
```bash
flutter build apk --release
```
El APK se genera normalmente en `build/app/outputs/flutter-apk/app-release.apk`.

## Estado de las funciones
- **Disponible en esta base:** operaciones CRUD de tareas, filtros, fecha/hora, prioridades, categorías, estado, calendario mensual, notas, tema oscuro y persistencia local.
- **Pendiente de implementación/configuración:** sincronización real en nube (Firebase u otro proveedor), notificaciones programadas exactas con permisos Android, repetición automática de tareas y exportación/importación de copias de seguridad.

Los recordatorios de esta versión son una integración inicial y todavía no garantizan una notificación futura exacta. No introducir datos importantes sin conservar una copia hasta que se implemente la función de respaldo.
