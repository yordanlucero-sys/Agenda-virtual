import 'package:flutter_test/flutter_test.dart';
import 'package:agenda_virtual/main.dart';

void main() {
  test('prioridades disponibles', () {
    expect(TaskPriority.values.length, 4);
  });
}
